<p align="center"><img src="banner_strip.jpg"></p>

M10-CUBE ecosystem is a community project and is the idea of a micro controller cube 10x10x10 cm. It is a hardware agnostic cube.

In practice only one rule must fulfilled for us to say that this is an M10 device.

- Used materials out of the self. 
- DIY friendly. 
- Think Green and Reuse philosophy

Soon we will publish PCBs, electronic circuits (Eagle and KiCAD) and 3D enclosures
Applications and software will follow so to encourage everyone to get involved

More on <a href="https://github.com/M10CUBE/M10/wiki">wiki</a> section



