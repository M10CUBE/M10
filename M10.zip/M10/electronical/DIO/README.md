<p align="center"><img src="m10_digital_in_out.jpg"></p>

